function abrirModal() {
    const modal = document.getElementById('faq-janela');
    modal.classList.add('abrir')
    modal.addEventListener('click', (e) => {
        if(e.target.id == 'fechar' || e.target.id == 'faq-janela') {
            modal.classList.remove('abrir')
    }
})
}

function irSobre() {
    const imagem = document.getElementById('isobre');
    const posicaoY = imagem.getBoundingClientRect().top;
    
    window.scrollTo( {
        top: posicaoY,
        behavior: 'smooth'
    })
}

function irContato() {
    const imagem = document.getElementById('icontato');
    const posicaoY = imagem.getBoundingClientRect().top;
    
    window.scrollTo( {
        top: posicaoY,
        behavior: 'smooth'
    })
}

function irServ() {
    const imagem = document.getElementById('iserv');
    const posicaoY = imagem.getBoundingClientRect().top;
    
    window.scrollTo( {
        top: posicaoY,
        behavior: 'smooth'
    })
}
function irInicio() {
    const imagem = document.getElementById('iinicio');
    const posicaoY = imagem.getBoundingClientRect().top;
    
    window.scrollTo( {
        top: posicaoY,
        behavior: 'smooth'
    })
}