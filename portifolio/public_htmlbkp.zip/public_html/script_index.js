function irparaBlog() {
    
    window.location.href = 'https://novotectest.000webhostapp.com/blog/blog.html';
}

function irparaSite() {
    
    window.location.href = 'https://novotectest.000webhostapp.com/digian/digian.html';
}

function irparaApp() {
    
    window.location.href = 'https://drive.google.com/file/d/1pBNkVf9eXUd5sVGTHuTE2Be_piPatFF7/view?usp=sharing';
}